/* no content, but patch(1) dislikes empty files */
